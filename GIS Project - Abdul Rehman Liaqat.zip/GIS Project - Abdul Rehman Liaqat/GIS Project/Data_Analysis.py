# -*- coding: utf-8 -*-
"""
Created on Thu Sep 28 10:52:05 2017

@author: Abdul Rehman
"""

import pandas as pd
import os

path = os.getcwd()
names = [path+"/"+"Crimes_in_the_City_of_Tulsa__Current_Year.csv",
         path+"/"+"Crimes_in_the_City_of_Tulsa__Previous_Year_at_a_Larger_Scale.csv",
         path+"/"+"Crimes_in_the_City_of_Tulsa__2_Years_Ago_Larger_Scale.csv"]

def concatenate_df(df,temp,col,val):
    temp[col] = ["1/1/200"+str(val)] * len(temp)
    return pd.concat([df,temp], ignore_index = True)


data = pd.DataFrame()
for index,name in enumerate(names):
    data = concatenate_df(data, pd.read_csv(name), "year", index) 

data_groups = data.groupby("UCC_CRIME_CLASS")
col = list(data.columns)
col[0] = 'X'
for name,groups in data_groups:
    groups.to_csv(str(name)+".csv", index = False, header = col)
